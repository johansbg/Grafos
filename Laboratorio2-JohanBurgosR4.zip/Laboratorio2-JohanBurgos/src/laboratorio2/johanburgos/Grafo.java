/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio2.johanburgos;

import java.awt.Rectangle;
import java.util.LinkedList;

/**
 *
 * @author johan
 */
public class Grafo {
    public LinkedList<Vertice> vertices = new LinkedList<Vertice>();
     String Caminos[][];
     int Distancias[][];
     String CaminoM[]= new String[100];
     int CamMinimo;
     int i = 0;
    public void Vorigen(Vertice v) {
        vertices.add(v);
    }
    public void Vdestino(Vertice v, Vertice vDestino, int i) {
        vertices.get(BuscarV(v.getDato())).addAdyacentes(vDestino);
        vertices.get(BuscarV(v.getDato())).Pesos.add(i);
    }
    public int BuscarV(String dato) {
        int x=0;
        for (Vertice ve : vertices) {
            if (ve.getDato().equals(dato)) {
                return x;
            }else{
                x++;
            }
        }
        return 0;
    }
    
    public void verM(){
        for (int i = 0; i < Caminos.length; i++){ 
            for (int j = 0; j< Caminos.length; j++){ 
               System.out.print (Caminos[i][j]);
            if (j!=Caminos[i].length-1) System.out.print("\t");
          }
          System.out.println(" ");
        }
    }       
    
    public void LLenarMCaminos(){
        Caminos = new String[vertices.size()][vertices.size()];
        for (int i = 0; i < Caminos.length; i++){ 
            for (int j = 0; j< Caminos.length; j++){ 
                Caminos[j][i]=vertices.get(i).getDato();
            }
        }    
    }
    public void LLenarMDistancias(){
        Distancias = new int[vertices.size()][vertices.size()];
        for (int i = 0; i < Distancias.length; i++){ 
            for (int j = 0; j< Distancias.length; j++){ 
                Distancias[j][i]=99999;
            }
        } 
        for (int j = 0; j < Distancias.length; j++) {
            Distancias[j][j]=0;
        }
        for (int i = 0; i < Distancias.length; i++){ 
            for (int j = 0; j< vertices.get(i).adyacente.size(); j++){ 
                Vertice v= vertices.get(i).adyacente.get(j);
                Distancias[i][BuscarV(v.getDato())]=vertices.get(i).Pesos.get(j);
            }
        } 
    }
    public void verMD(){
        for (int i = 0; i < Distancias.length; i++){ 
            for (int j = 0; j< Distancias.length; j++){ 
               System.out.print (Distancias[i][j]);
            if (j!=Distancias[i].length-1) System.out.print("\t");
          }
          System.out.println(" ");
        }
    }
    
    public void algoritmoFloydWarshall(){
        int nVertices = Distancias.length;
        int tmp;
        for (int k = 0; k < nVertices; k++) {
            for (int i = 0; i < nVertices; i++) {
                for (int j = 0; j < nVertices; j++) {    
                    tmp = Distancias[i][k]+Distancias[k][j];
                    if (tmp< Distancias[i][j]) {
                        Distancias[i][j]=tmp;
                        Caminos[i][j]=Caminos[k][k];
                    }
                }
            }
        } 
        
    }
    public void CaminoMasCorto(String A, String B, int sw, String ant){
        if(!A.equals(B)){
            if(!ant.equals(B)){
                    CaminoM[i]=B;
                    i++;
                    if(sw == 0){
                        CamMinimo = Distancias[BuscarV(A)][BuscarV(B)];
                    }
                    CaminoMasCorto(A,Caminos[BuscarV(A)][BuscarV(B)],1,B);
            }else{
                CaminoM[i]=A;
            }
        }else{
            System.out.println(" ");
            System.out.println("Es el mismo vertice");
        }
    }
    public void verC(){
        for (int j = i; j >= 0; j--) {
                if (j!=0) {
                    System.out.print(CaminoM[j]+"-");
                }else{
                    System.out.print(CaminoM[j]);
                }
                     
            }
            System.out.println("  ");
            System.out.println("Distancia = "+CamMinimo);  
    }
    
    public void caminonuevo(){
         Caminos = null;
         Distancias=null;
         CamMinimo=0;
         CaminoM = new String[100];
         i = 0;
    }
    public boolean VerificarV(Vertice v) {
        for (Vertice ve : vertices) {
            if (v.getDato().equals(ve.getDato())) {
                return true;
            }
        }
        return false;
    }
    public boolean VerificarCoordenadas(int x1, int y1, int FX1, int FY1) {
        for (Vertice ve : vertices) {
            if (new Rectangle(ve.x,ve.y,ve.FX+120,ve.FY+120).intersects(new Rectangle(x1, y1, FX1,FY1))) {
                return true;
            }
        }
        return false;
    }
    public String VerificarSeleccion(int x1, int y1) {
        for (Vertice ve : vertices) {
            if (new Rectangle(ve.x,ve.y,ve.FX+20,ve.FY+20).intersects(new Rectangle(x1, y1, 10 ,ve.FY))) {
                return ve.getDato();
            }
        }
        return null;
    }
    public void eliminarV(int n){
        vertices.remove(n);
    }
    public void eliminarA(Vertice n){
        for (Vertice v : vertices) {
            for (int q = 0; q < v.adyacente.size() ; q++) {
                if (n == v.adyacente.get(q)) {
                    v.adyacente.remove(q);
                    v.Pesos.remove(q);
                }
            }
        }
    }
}
