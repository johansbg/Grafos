/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio2.johanburgos;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
/**
 *
 * @author johan
 */
public class Ventana extends javax.swing.JFrame {
    Grafo g = new Grafo();
    private FontMetrics fm = null;
    int sel =0,SW=0;
    Vertice v1,v2,ve;
    
    /**
     * Creates new form Ventana
     */
    public Ventana() {
        initComponents();
        this.requestFocus();
        this.setLocationRelativeTo(null);
        this.setBackground(Color.white);
        Imagen im = new Imagen(Grafico);
        Grafico.add(im).repaint();
        JOptionPane.showMessageDialog(null, "¡IMPORTANTE! : Leer Ayudas");
        Origen.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent arg0) {
                rellenaCombo2((String) Origen.getSelectedItem());
        }
        });
    }
    public void llenarComboB(){
        for (Vertice v : g.vertices) {
            Origen.addItem(v.getDato());
        }
    }
    private void rellenaCombo2(String seleccionEnCombo1) {
     Destino.removeAllItems();
     for (Vertice v : g.vertices) {
            if (v.adyacente!=null && !v.getDato().equals(seleccionEnCombo1)) {
                if (VerAdyacentes(seleccionEnCombo1,v.getDato()) && VerAdyacentes(v.getDato(),seleccionEnCombo1)) {
                    Destino.addItem(v.getDato());
                }
            }else{
                if (v.adyacente==null && !v.getDato().equals(seleccionEnCombo1) && VerAdyacentes(v.getDato(),seleccionEnCombo1)) {
                    Destino.addItem(v.getDato());
                }
            }
     }
     
    }
    public boolean VerAdyacentes(String i,String dato){
        Vertice v = g.vertices.get(g.BuscarV(i));
        for (Vertice a : v.adyacente) {
            if (a.getDato().equals(dato)) {
                return false;
            }
        }
        return true;
    }
    
    public void GraficarV(int x , int y , Vertice v ){
            Graphics2D gra = (Graphics2D) Grafico.getGraphics();
            gra.setFont( new Font( "Tahoma", Font.BOLD, 18 ) );
            fm = gra.getFontMetrics();
            int width = fm.stringWidth(v.getDato()+"");
            gra.setColor(Color.CYAN);
            gra.fillRect(x, y, width + 6, fm.getHeight());
            gra.setColor(Color.BLACK);
            gra.drawRect(x, y, width + 6, fm.getHeight());
            gra.drawString(v.getDato()+"", x + 3, y + (fm.getLeading() + fm.getAscent()));
    }
    public void GraficarVC(int x , int y , Vertice v ){
            Graphics2D gra = (Graphics2D) Grafico.getGraphics();
            gra.setFont( new Font( "Tahoma", Font.BOLD, 18 ) );
            fm = gra.getFontMetrics();
            int width = fm.stringWidth(v.getDato()+"");
            gra.setColor(Color.RED);
            gra.fillRect(x, y, width + 6, fm.getHeight());
            gra.setColor(Color.BLACK);
            gra.drawRect(x, y, width + 6, fm.getHeight());
            gra.drawString(v.getDato()+"", x + 3, y + (fm.getLeading() + fm.getAscent()));
    }
    public void GraficarE(int x , int y , Vertice v ){
            Graphics2D gra = (Graphics2D) Grafico.getGraphics();
            gra.setFont( new Font( "Tahoma", Font.BOLD, 18 ) );
            fm = gra.getFontMetrics();
            int width = fm.stringWidth(v.getDato()+"");
            gra.drawString(v.getDato()+"", x + 3, y + (fm.getLeading() + fm.getAscent()));
            gra.setColor(Color.yellow);
            gra.drawRect(x, y, width + 6, fm.getHeight());
    }
    private final int ARR_SIZE = 7; 

    public  void drawArrow(int x1, int y1, int x2, int y2 , String costo) { 
       Graphics2D g = (Graphics2D) Grafico.getGraphics();
       double dx = x2 - x1, dy = y2 - y1; 
       double angle = Math.atan2(dy, dx); 
       int len = (int) Math.sqrt(dx*dx + dy*dy); 
       AffineTransform at = AffineTransform.getTranslateInstance(x1, y1); 
       at.concatenate(AffineTransform.getRotateInstance(angle)); 
       g.transform(at);
       Color C=new Color((int) Math.floor(Math.random() * 255), (int) Math.floor(Math.random() * 255), (int) Math.floor(Math.random() * 255));
       g.setColor(C);
       g.drawLine(0, 0, len, 0); 
       g.fillPolygon(new int[] {len, len-ARR_SIZE, len-ARR_SIZE, len}, 
           new int[] {0, -ARR_SIZE, ARR_SIZE, 0}, 4);
       g.setFont( new Font( "Tahoma", Font.BOLD, 20 ) );
       //intentar arreglar string
        if (x1<x2) {
            if (y1<y2) {
            g.drawString(costo, ((2/(x2-x1))+75), (2/(y2-y1)));
        }else{
            g.drawString(costo, ((2/(x2-x1))+75), (2/(y2-y1)));
        }
        }else{
            if (y1<y2) {
                g.drawString(costo, ((2/(x1-x2))+75), (2/(y2-y1)));
            }else{
                g.drawString(costo, ((2/(x1-x2)))+75, (2/(y2-y1)));
        }
        }
       
      } 
    public  void drawArrowC(int x1, int y1, int x2, int y2 , String costo,Color c, Graphics2D g) { 
       double dx = x2 - x1, dy = y2 - y1; 
       double angle = Math.atan2(dy, dx); 
       int len = (int) Math.sqrt(dx*dx + dy*dy); 
       AffineTransform at = AffineTransform.getTranslateInstance(x1, y1); 
       at.concatenate(AffineTransform.getRotateInstance(angle)); 
       g.transform(at);
       g.setColor(c);
       g.drawLine(0, 0, len, 0); 
       g.fillPolygon(new int[] {len, len-ARR_SIZE, len-ARR_SIZE, len}, 
           new int[] {0, -ARR_SIZE, ARR_SIZE, 0}, 4);
       g.setFont( new Font( "Tahoma", Font.BOLD, 20 ) );
        if (x1<x2) {
            if (y1<y2) {
            g.drawString(costo, ((2/(x2-x1))+75), (2/(y2-y1)));
        }else{
            g.drawString(costo, ((2/(x2-x1))+75), (2/(y2-y1)));
        }
        }else{
            if (y1<y2) {
                g.drawString(costo, ((2/(x1-x2))+75), (2/(y2-y1)));
            }else{
                g.drawString(costo, ((2/(x1-x2)))+75, (2/(y2-y1)));
        }
        }
       
      }
    public void dibujardenuevo(){
        for (Vertice v : g.vertices) {
            GraficarV(v.getX(), v.getY(), v);
        }
        for (Vertice V: g.vertices) {
            int k=0;
            for (Vertice VD : V.adyacente) {
                if (V.getY()>VD.getY()) {
                    drawArrow((V.getX()+(V.FX)), V.getY(), VD.getX(), VD.getY(),V.Pesos.get(k).toString());
                }else{
                    drawArrow((V.getX()+(V.FX)), (V.getY()+(V.FY)), VD.getX(), VD.getY(),V.Pesos.get(k).toString());
                }
                k++;
            }
        }
    }
    public void dibujardenuevoC(){
        for (Vertice v : g.vertices) {
            GraficarV(v.getX(), v.getY(), v);
        }
        for (Vertice V: g.vertices) {
            int k=0;
            for (Vertice VD : V.adyacente) {
                Graphics2D g = (Graphics2D) Grafico.getGraphics();
                if (V.getY()>VD.getY()) {
                    drawArrowC((V.getX()+(V.FX)), V.getY(), VD.getX(), VD.getY(),V.Pesos.get(k).toString(),Color.BLACK,g);
                }else{
                    drawArrowC((V.getX()+(V.FX)), (V.getY()+(V.FY)), VD.getX(), VD.getY(),V.Pesos.get(k).toString(),Color.BLACK,g);
                }
                k++;
            }
        }
    }
    public void borrar(){
        JOptionPane.showMessageDialog(null, "Eliminacion exitosa");
        g.eliminarV(g.BuscarV(g.VerificarSeleccion(ve.x, ve.y)));
        g.eliminarA(ve);
        Grafico.repaint();
        JOptionPane.showMessageDialog(null, "Grafo actualizado");
        Origen.removeAllItems();
        llenarComboB();
        dibujardenuevo();
    }
    public void Newgrafo(){
        g.vertices.clear();
        Grafico.repaint();
        JOptionPane.showMessageDialog(null, "Grafo actualizado");
        Origen.removeAllItems();
        llenarComboB();
        dibujardenuevo();
    }
    
    public void graficarC(){
        for (int i = 0; i < g.CaminoM.length; i++) {
            Vertice v = g.vertices.get(g.BuscarV(g.CaminoM[i]));
            GraficarVC(v.getX(), v.getY(), v);
        }
        System.out.println("g.i "+g.i);
        for (int j = g.i; j > 0; j--) {
            Vertice V = g.vertices.get(g.BuscarV(g.CaminoM[j]));
            Vertice VD = g.vertices.get(g.BuscarV(g.CaminoM[j-1]));
            String cadena = Integer.toString(V.Pesos.get(V.BuscarAdyacente(VD.getDato())));
            Graphics2D g = (Graphics2D) Grafico.getGraphics();
            g.setStroke(new BasicStroke(4));
                if (V.getY()>VD.getY()) {
                    drawArrowC((V.getX()+(V.FX)), V.getY(), VD.getX(), VD.getY(),cadena,Color.RED,g);
                }else{
                    drawArrowC((V.getX()+(V.FX)), (V.getY()+(V.FY)), VD.getX(), VD.getY(),cadena,Color.RED,g);
                } 
            
        }
           
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        Origen = new javax.swing.JComboBox<>();
        Destino = new javax.swing.JComboBox<>();
        Grafico = new javax.swing.JPanel();
        Costo = new javax.swing.JSpinner();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        jLabel1.setText("Origen :");

        jLabel2.setText("Destino :");

        jLabel3.setText("Costo :");

        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Buscar Camino minimo");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel4.setText("Seleccione la Posicion de sus ciudades");

        Grafico.setBackground(new java.awt.Color(0, 255, 255));
        Grafico.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Grafico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GraficoMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout GraficoLayout = new javax.swing.GroupLayout(Grafico);
        Grafico.setLayout(GraficoLayout);
        GraficoLayout.setHorizontalGroup(
            GraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        GraficoLayout.setVerticalGroup(
            GraficoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 474, Short.MAX_VALUE)
        );

        jMenu1.setText("Ayudas");

        jMenuItem1.setText("Como borrar  (Click + Delete)");
        jMenuItem1.setToolTipText("Click+Del");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem3.setText("Como crear un nuevo mapa (F5)");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem2.setText("Actualizar Grafo (F3)");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(Origen, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(Destino, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Costo, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 167, Short.MAX_VALUE)
                                .addComponent(jButton2)
                                .addGap(36, 36, 36))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Grafico, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Grafico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(jButton2)
                        .addComponent(Origen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Destino, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Costo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Vertice V = g.vertices.get(g.BuscarV(Origen.getItemAt(Origen.getSelectedIndex())));
        if (Destino.getItemAt(Destino.getSelectedIndex())!=null) {
            Vertice VD = g.vertices.get(g.BuscarV(Destino.getItemAt(Destino.getSelectedIndex())));
            g.Vdestino(V, VD, (int) Costo.getValue());
            Origen.removeAllItems();
            llenarComboB();
            if (V.getY()>VD.getY()) {
                drawArrow((V.getX()+(V.FX)), V.getY(), VD.getX(), VD.getY(),Costo.getValue().toString());
            }else{
                drawArrow((V.getX()+(V.FX)), (V.getY()+(V.FY)), VD.getX(), VD.getY(),Costo.getValue().toString());
            }
            Costo.setValue(0);
        }else{
            JOptionPane.showMessageDialog(null, "Ya no puedes poner mas conexiones desde este vertice");
        }
        this.requestFocus();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void GraficoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_GraficoMouseClicked
        //verificar todo y ponerlo bonito 
        if (g.VerificarSeleccion(evt.getX(), evt.getY())==null) {
            this.requestFocus();
            String nombre = JOptionPane.showInputDialog("Digite El nombre de la Ciudad");
            //verificar cancelar y que no se pueda agregar en blanco
            Graphics2D gra = (Graphics2D) Grafico.getGraphics();
            fm = gra.getFontMetrics();
            int width = fm.stringWidth(nombre+"");
            Vertice v = new Vertice(nombre, evt.getX(), evt.getY(), width + 6, fm.getHeight());
            if (g.VerificarV(v) == false ) {
                if (g.VerificarCoordenadas(evt.getX(), evt.getY(), width + 6, fm.getHeight())==false) {
                    GraficarV(evt.getX(), evt.getY(), v);
                    g.Vorigen(v);
                    Origen.removeAllItems();
                    llenarComboB();
                }else{
                    JOptionPane.showMessageDialog(null, "No puedes crear una ciudad aqui");
                }
            }else{
                JOptionPane.showMessageDialog(null, "Ciudad ya creada");
            }
        }else{
            if (g.VerificarSeleccion(evt.getX(), evt.getY())!=null) {
                SW=1;
                this.requestFocus();
                ve = g.vertices.get(g.BuscarV(g.VerificarSeleccion(evt.getX(), evt.getY())));
                GraficarE(ve.getX(), ve.getY(), ve);
                if (sel==0) {
                    v1 = g.vertices.get(g.BuscarV(g.VerificarSeleccion(evt.getX(), evt.getY())));
                    GraficarE(v1.getX(), v1.getY(), v1);
                    sel=1;
                }else{
                    v2 = g.vertices.get(g.BuscarV(g.VerificarSeleccion(evt.getX(), evt.getY())));
                    GraficarE(v2.getX(), v2.getY(), v2);
                    sel=0;
                }
                }
            }
        this.requestFocus();
        
    }//GEN-LAST:event_GraficoMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
          JOptionPane.showMessageDialog(null, "Haga click en DOS vertices y luego unda Enter. (Si desea cancelar oprima 0)");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        sel=0;
        if (evt.getKeyCode()==KeyEvent.VK_F5) {
            Newgrafo();
        }else{
            if (evt.getKeyCode()==KeyEvent.VK_F3) {
                Grafico.repaint();
                JOptionPane.showMessageDialog(null, "Grafo actualizado");
                Origen.removeAllItems();
                llenarComboB();
                dibujardenuevo();
            }else{
                if (SW==1) {
                    if (evt.getKeyCode()==KeyEvent.VK_BACK_SPACE){
                        borrar();
                    }else{
                        if (evt.getKeyCode()==KeyEvent.VK_ENTER){
                                if (v2!=null) {
                                       g.LLenarMCaminos();
                                       g.LLenarMDistancias();
                                       g.algoritmoFloydWarshall();
                                       g.CaminoMasCorto(v1.getDato(), v2.getDato(), 0, "AAAAAAA");
                                       if (g.CamMinimo!= 99999) {
                                            JOptionPane.showMessageDialog(null, "Camino minimo entre "+v1.getDato()+" y "+v2.getDato()+" es igual a: "+g.CamMinimo);
                                            dibujardenuevoC();
                                            graficarC();
                                            g.caminonuevo();
                                        }else{
                                           dibujardenuevo();
                                           JOptionPane.showMessageDialog(null, "No es posible este camino");
                                       }
                                }
                        }else{
                            if (evt.getKeyCode()==KeyEvent.VK_0) {
                                dibujardenuevo();
                                JOptionPane.showMessageDialog(null, "Accion cancelada");
                            }else{
                                dibujardenuevo();
                                JOptionPane.showMessageDialog(null, "Dato mal digitado");
                            }
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_formKeyPressed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        JOptionPane.showMessageDialog(null, "Haga click en el vertice que desee borrar y luego unda Delete. (Si desea cancelar oprima 0)");
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        JOptionPane.showMessageDialog(null, "Presione F5");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(null, "Presione F3");
    }//GEN-LAST:event_jMenuItem2ActionPerformed
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner Costo;
    private javax.swing.JComboBox<String> Destino;
    private javax.swing.JPanel Grafico;
    private javax.swing.JComboBox<String> Origen;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    // End of variables declaration//GEN-END:variables
}
